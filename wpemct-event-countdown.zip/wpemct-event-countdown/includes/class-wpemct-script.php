<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package WP Event Manager Countdown Timer
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Wpemct_Script {

	function __construct() {

		// Action to add style at front side
		add_action( 'wp_enqueue_scripts', array($this, 'wpemct_front_style') );

		// Action to add script at front side
		add_action( 'wp_enqueue_scripts', array($this, 'wpemct_front_script') );

		// Action to add style in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wpemct_admin_style') );

		// Action to add script in backend
		add_action( 'admin_enqueue_scripts', array($this, 'wpemct_admin_script') );
	}

	/**
	 * Function to add style at front side
	 * 
	 * @package WP Event Manager Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_front_style() {

		// Registring and enqueing public css
		wp_register_style( 'wpemct-public-css', WPEMCT_URL.'assets/css/wpemct-timecircles.css', array(), WPEMCT_VERSION );
		wp_enqueue_style( 'wpemct-public-css' );
	}

	/**
	 * Function to add script at front side
	 * 
	 * @package WP Event Manager Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_front_script() {

		// Registring timer script
		wp_register_script( 'wpemct-timecircle-js', WPEMCT_URL.'assets/js/wpemct-timecircles.js', array('jquery'), WPEMCT_VERSION, true );

		// Registring public script
		wp_register_script( 'wpemct-public-js', WPEMCT_URL.'assets/js/wpemct-public-js.js', array('jquery'), WPEMCT_VERSION, true );
	}

		/**
	 * Enqueue admin styles
	 * 
	 * @package WP Event Manager Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_admin_style( $hook ) {

		global $post_type;

		// If page is plugin setting page then enqueue script
		if( $post_type == WPEMCT_POST_TYPE ) {

			wp_enqueue_style( 'wp-color-picker' );

			wp_register_style( 'wpemct-ui-timepicker-addon', WPEMCT_URL.'assets/css/wpemct-ui-timepicker-addon.css', null, WPEMCT_VERSION );
			wp_enqueue_style( 'wpemct-ui-timepicker-addon' );

			wp_register_style( 'wpemct-admin-css', WPEMCT_URL.'assets/css/wpemct-admin-css.css', null, WPEMCT_VERSION );
			wp_enqueue_style( 'wpemct-admin-css' );
		}
	}

	/**
	 * Enqueue admin script
	 * 
	 * @package WP Event Manager Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_admin_script( $hook ) {

		global $post_type;

		wp_register_script( 'wpemct-ui-timepicker-addon-js', WPEMCT_URL.'assets/js/wpemct-ui-timepicker-addon.js', array('jquery'), WPEMCT_VERSION, true );

		wp_register_script( 'wpemct-admin-js', WPEMCT_URL.'assets/js/wpemct-admin-js.js', array('jquery'), WPEMCT_VERSION, true );

		// If page is plugin setting page then enqueue script
		if( $post_type == WPEMCT_POST_TYPE ) {

			wp_enqueue_script( 'wp-color-picker' );
			wp_enqueue_script( 'jquery-ui-datepicker' );
			wp_enqueue_script( 'jquery-ui-slider' );

			// Registring admin script
			wp_enqueue_script( 'wpemct-ui-timepicker-addon-js' );
			wp_enqueue_script( 'wpemct-admin-js' );
		}

		// How it work page
		if( $hook == WPEMCT_POST_TYPE.'_page_wpemct-designs' ) {
			wp_enqueue_script( 'wpemct-admin-js' );
		}
	}
}

$wpemct_script = new Wpemct_Script();