jQuery(document).ready(function ($) {

    if ($('.wplc-color-box').length > 0) {
        $('.wplc-color-box').wpColorPicker();
    }

    if ($('#wpemct-countdown-datepicker').length > 0) {
        $('#wpemct-countdown-datepicker').datetimepicker({
            dateFormat: 'yy-mm-dd',
            timeFormat: 'HH:mm:ss',
            minDate: 0,
            changeMonth: true,
            changeYear: true,
        });
    }

    if ($('.wpemct-circle-slider').length > 0) {
        $(".wpemct-circle-slider").slider({
            min: 0.0033333333333333335,
            max: 0.13333333333333333,
            step: 0.003333333,
            slide: function (event, ui) {
                $(this).parent().find(".wpemct-number").val(ui.value);
            },
            create: function (event, ui) {
                $(this).slider('value', $(this).parent().find(".wpemct-number").val());
            }
        });
    }

    if ($('.wpemct-background-slider').length > 0) {
        $(".wpemct-background-slider").slider({
            min: 0.1,
            max: 3,
            step: 0.1,
            slide: function (event, ui) {
                $(this).parent().find(".wpemct-number").val(ui.value);
            },
            create: function (event, ui) {
                $(this).slider('value', $(this).parent().find(".wpemct-number").val());
            }
        });
    }

    /* Click to Copy the Text */
    $(document).on('click', '.wpemct-copy-clipboard', function () {
        var copyText = $(this);
        copyText.select();
        document.execCommand("copy");
    });
});