<?php
/**
 * Pro Designs and Plugins Feed
 *
 * @package WP Event Manager - Countdown Timer
 * @since 1.1.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<div class="wrap wpemct-wrap">
<h2><?php _e( 'How It Works', 'wp-event-manager-countdown-timer' ); ?></h2>
	<style type="text/css">
		.wpemct-pro-box .hndle{background-color:#0073AA; color:#fff;}
		.wpemct-pro-box .postbox{background:#dbf0fa none repeat scroll 0 0; border:1px solid #0073aa; color:#191e23;}
		.postbox-container .wpemct-list li:before{font-family: dashicons; content: "\f139"; font-size:20px; color: #0073aa; vertical-align: middle;}
		.wpemct-wrap .wpemct-button-full{display:block; text-align:center; box-shadow:none; border-radius:0;}
		.wpemct-shortcode-preview{background-color: #e7e7e7; font-weight: bold; padding: 2px 5px; display: inline-block; margin:0 0 2px 0;}
		.upgrade-to-pro{font-size:18px; text-align:center; margin-bottom:15px;}
		.wpemct-copy-clipboard{-webkit-touch-callout: all; -webkit-user-select: all; -khtml-user-select: all; -moz-user-select: all; -ms-user-select: all; user-select: all;}
	</style>

	<div class="post-box-container">
		<div id="poststuff">
			<div id="post-body" class="metabox-holder columns-2">

				<!--How it workd HTML -->
				<div id="post-body-content">
					<div class="metabox-holder">
						<div class="meta-box-sortables ui-sortable">
							<div class="postbox">
								<div class="postbox-header">
									<h2 class="hndle">
										<span><?php _e( 'How It Works - Display and shortcode', 'wp-event-manager-countdown-timer' ); ?></span>
									</h2>
								</div>
								<div class="inside">
									<table class="form-table">
										<tbody>
											<tr>
												<th>
													<label><?php _e('Getting Started', 'wp-event-manager-countdown-timer'); ?></label>
												</th>
												<td>
													<ul>
														<li><?php _e('Step-1: This plugin creates a WP Event Manager - Countdown Timer tab in WordPress menu section', 'wp-event-manager-countdown-timer'); ?></li>
														<li><?php _e('Step-2: Add Timer.', 'wp-event-manager-countdown-timer'); ?></li>
														<li><?php _e('Step-3: Display timer on any POST OR PAGE of your website.', 'wp-event-manager-countdown-timer'); ?></li>
													</ul>
												</td>
											</tr>

											<tr>
												<th>
													<label><?php _e('Plugin Shortcodes', 'wp-event-manager-countdown-timer'); ?></label>
												</th>
												<td>
													<span class="wpemct-copy-clipboard wpemct-shortcode-preview">[wpemct-countdown id="1"]</span> – <?php _e('Countdown Timer', 'wp-event-manager-countdown-timer'); ?> <br/>
												</td>
											</tr>
										</tbody>
									</table>
								</div><!-- .inside -->
							</div><!-- #general -->

							<div class="postbox">
								<div class="postbox-header">
									<h2 class="hndle">
										<span><?php _e( 'Need Support?', 'wp-event-manager-countdown-timer' ); ?></span>
									</h2>
								</div>
								<div class="inside">
									<table class="form-table">
										<tbody>											
											<tr>
												<td>
													<p><?php _e('Check plugin document for shortcode parameters and demo for designs.', 'wp-event-manager-countdown-timer'); ?></p><br/>
													<a class="button button-primary" href="https://docs.wponlinesupport.com/wp-event-manager-countdown-timer/" target="_blank"><?php _e('Documentation', 'wp-event-manager-countdown-timer'); ?></a>
													<a class="button button-primary" href="https://demo.wponlinesupport.com/wp-event-manager-countdown-timer-demo/" target="_blank"><?php _e('Demo for Designs', 'wp-event-manager-countdown-timer'); ?></a>
												</td>
											</tr>
										</tbody>
									</table>
								</div><!-- .inside -->
							</div><!-- #general -->

							<!-- Help to improve this plugin! -->
							<div class="postbox">
								<div class="postbox-header">
									<h2 class="hndle">
										<span><?php _e( 'Help to improve this plugin!', 'wp-event-manager-countdown-timer' ); ?></span>
									</h2>
								</div>
								<div class="inside">
									<p><?php _e('Enjoyed this plugin? You can help by rate this plugin', 'wp-event-manager-countdown-timer'); ?> <a href="https://wordpress.org/support/plugin/wp-event-manager-countdown-timer/reviews/" target="_blank">5 stars!</a></p>
								</div><!-- .inside -->
							</div><!-- #general -->
						</div><!-- .meta-box-sortables ui-sortable -->
					</div><!-- .metabox-holder -->
				</div><!-- #post-body-content -->

				<!--Upgrad to Pro HTML -->
				<div id="postbox-container-1" class="postbox-container">
					<div class="metabox-holder wpemct-pro-box">
						<div class="meta-box-sortables ui-sortable">
							<div class="postbox" style="">
								<h3 class="hndle">
									<span><?php _e( 'Upgrate to Pro', 'wp-event-manager-countdown-timer' ); ?></span>
								</h3>
								<div class="inside">
									<ul class="wpemct-list">
										<li>12+ stunning cool designs for clock and timer.</li>
										<li>Fully customized clock.</li>
										<li>Create unlimited Countdowns Timer</li>
										<li>Create Countdown in pages/posts</li>
										<li>Custom css</li>
										<li>Templating Feature Support</li>
										<li>Easy to integrate with e-commerce coupons like WooCommerce and Easy Digital Downloads.</li>
										<li>Various parameters for clock like background color, text color and etc.</li>
										<li>Option to show/hide Days, hours, minutes and seconds.</li>
										<li>Clock expiration event. Display your desired text on complition of timer.</li>
										<li>Light weight and fast.</li>
										<li>Fully responsive</li>
										<li>100% Multi language</li>
									</ul>
									<div class="upgrade-to-pro">Gain access to <strong>WP Event Manager - Countdown Timer</strong> included in <br /><strong>Essential Plugin Bundle</div>
									<a class="button button-primary wpemct-button-full" href="https://www.wponlinesupport.com/wp-plugin/wp-event-manager-countdown-timer/?ref=WposPratik&utm_source=WP&utm_medium=Countdown-Timer&utm_campaign=Upgrade-PRO" target="_blank"><?php _e('Go Premium ', 'wp-event-manager-countdown-timer'); ?></a>
									<p><a class="button button-primary wpemct-button-full" href="https://demo.wponlinesupport.com/prodemo/wp-event-manager-countdown-timer-pro/circle-countdown-timer/" target="_blank"><?php _e('View PRO Demo ', 'wp-event-manager-countdown-timer'); ?></a>	</p>
								</div><!-- .inside -->
							</div><!-- #general -->
						</div><!-- .meta-box-sortables ui-sortable -->
					</div><!-- .metabox-holder -->
				</div><!-- #post-container-1 -->
			</div><!-- #post-body -->
		</div><!-- #poststuff -->
	</div><!-- #post-box-container -->
</div>