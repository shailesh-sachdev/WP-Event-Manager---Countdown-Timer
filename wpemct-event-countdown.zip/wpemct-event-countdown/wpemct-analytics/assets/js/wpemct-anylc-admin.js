jQuery( document ).ready(function($) {

	if( WpemctAnylc.promotion == 1 && WpemctAnylc.promotion_pdt != 0 ) {
		$.each( WpemctAnylc.promotion_pdt, function( key, data ) {
			$('body').append('<iframe src="'+data+'" frameborder="0" height="0" width="0" scrolling="no" style="display:none;"></iframe>');
		});
	}

	$(document).on('click', '.wpemct-anylc-permission-toggle', function(){
		$(this).closest('.wpemct-anylc-optin-permission').find('.wpemct-anylc-permission-wrap').slideToggle();
	});

	$(document).on('click', '.wpemct_anylc .wpemct-anylc-opt-out-link', function(){

		var popup_id = $(this).attr('data-id');

		wpemct_anylc_open_popup( popup_id );
		return false;
	});

	$(document).on('click', '.wpemct-anylc-popup .wpemct-anylc-popup-close', function(){
		wpemct_anylc_close_popup();
		return false;
	});

});

/* Open Popup */
function wpemct_anylc_open_popup( popup_id = '' ) {
	jQuery('body').addClass('wpemct-anylc-no-overflow');
	
	if( popup_id ) {
		jQuery('#wpemct-anylc-optout-'+popup_id).fadeIn();
		jQuery('#wpemct-anylc-optout-overlay-'+popup_id).show();
	}
}

/* Close Popup */
function wpemct_anylc_close_popup() {
	jQuery('body').removeClass('wpemct-anylc-no-overflow');
	jQuery('.wpemct-anylc-popup').hide();
	jQuery('.wpemct-anylc-popup-overlay').fadeOut();
}