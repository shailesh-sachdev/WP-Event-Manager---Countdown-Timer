<?php
/**
 * Register Post type functionality
 *
 * @package WP Event Manager - Countdown Timer
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to register post type
 * 
 * @package Countdown Timer
 * @since 1.0.0
 */
function wpemct_register_post_type() {

	$wpemct_post_lbls = apply_filters( 'wpemct_timer_post_labels', array(
								'name'                 	=> __('WP Countdown Timer', 'wp-event-manager-countdown-timer'),
								'singular_name'        	=> __('WP Countdown Timer', 'wp-event-manager-countdown-timer'),
								'add_new'              	=> __('Add Timer', 'wp-event-manager-countdown-timer'),
								'add_new_item'         	=> __('Add New Timer', 'wp-event-manager-countdown-timer'),
								'edit_item'            	=> __('Edit Timer', 'wp-event-manager-countdown-timer'),
								'new_item'             	=> __('New Timer', 'wp-event-manager-countdown-timer'),
								'view_item'            	=> __('View Timer', 'wp-event-manager-countdown-timer'),
								'search_items'         	=> __('Search Timer', 'wp-event-manager-countdown-timer'),
								'not_found'            	=> __('No Timer Found', 'wp-event-manager-countdown-timer'),
								'not_found_in_trash'   	=> __('No Timer Found in Trash', 'wp-event-manager-countdown-timer'),
								'parent_item_colon'    	=> '',
								'menu_name'           	=> __('Countdown Timer', 'wp-event-manager-countdown-timer')
							));

	$wpemct_slider_args = array(
		'labels'				=> $wpemct_post_lbls,
		'public'				=> false,
		'show_ui'				=> true,
		'query_var'				=> false,
		'rewrite'				=> false,
		'capability_type'		=> 'post',
		'hierarchical'			=> false,
		'menu_icon'				=> 'dashicons-clock',
		'supports'				=> apply_filters('wpemct_timer_post_supports', array('title')),
	);

	// Register slick slider post type
	register_post_type( WPEMCT_POST_TYPE, apply_filters( 'wpemct_registered_post_type_args', $wpemct_slider_args ) );
}

// Action to register plugin post type
add_action('init', 'wpemct_register_post_type');

/**
 * Function to update post message for team showcase
 * 
 * @package WP Event Manager - Countdown Timer
 * @since 1.0.0
 */
function wpemct_post_updated_messages( $messages ) {

	global $post, $post_ID;

	$messages[WPEMCT_POST_TYPE] = array(
		0 => '', // Unused. Messages start at index 1.
		1 => sprintf( __( 'Timer updated.', 'wp-event-manager-countdown-timer' ) ),
		2 => __( 'Custom field updated.', 'wp-event-manager-countdown-timer' ),
		3 => __( 'Custom field deleted.', 'wp-event-manager-countdown-timer' ),
		4 => __( 'Timer updated.', 'wp-event-manager-countdown-timer' ),
		5 => isset( $_GET['revision'] ) ? sprintf( __( 'Timer restored to revision from %s', 'wp-event-manager-countdown-timer' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __( 'Timer published.', 'wp-event-manager-countdown-timer' ) ),
		7 => __( 'Timer saved.', 'wp-event-manager-countdown-timer' ),
		8 => sprintf( __( 'Timer submitted.', 'wp-event-manager-countdown-timer' ) ),
		9 => sprintf( __( 'Timer scheduled for: <strong>%1$s</strong>.', 'wp-event-manager-countdown-timer' ),
		  date_i18n( __( 'M j, Y @ G:i', 'wp-event-manager-countdown-timer' ), strtotime( $post->post_date ) ) ),
		10 => sprintf( __( 'Timer draft updated.', 'wp-event-manager-countdown-timer' ) ),
	);

	return $messages;
}

// Filter to update slider post message
add_filter( 'post_updated_messages', 'wpemct_post_updated_messages' );