<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of plugin
 *
 * @package WP Event Manager Countdown Timer
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Wpemct_Admin {

	function __construct() {

		// Action to add admin menu
		add_action( 'admin_menu', array($this, 'wpemct_register_menu'), 12 );

		// Action to add metabox
		add_action( 'add_meta_boxes', array($this, 'wpemct_post_sett_metabox') );

		// Action to save metabox
		add_action( 'save_post', array($this, 'wpemct_save_metabox_value') );

		// Admin Prior Process
		add_action( 'admin_init', array($this, 'wpemct_admin_init_process') );

		// Action to add custom column to Timer listing
		add_filter( 'manage_'.WPEMCT_POST_TYPE.'_posts_columns', array($this, 'wpemct_posts_columns') );

		// Action to add custom column data to Timer listing
		add_action('manage_'.WPEMCT_POST_TYPE.'_posts_custom_column', array($this, 'wpemct_post_columns_data'), 10, 2);
	}

	/**
	 * Function to add menu
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_register_menu() {

		// How It Work Page
		add_submenu_page( 'edit.php?post_type='.WPEMCT_POST_TYPE, __('How it works - WP Event Manager - Countdown Timer', 'countdown-timer-ultimate'), __('How It Works', 'countdown-timer-ultimate'), 'manage_options', 'wpemct-designs', array($this, 'wpemct_designs_page') );

		// Premium Feature Page
		add_submenu_page( 'edit.php?post_type='.WPEMCT_POST_TYPE, __('Upgrade to PRO - WP Event Manager - Countdown Timer', 'countdown-timer-ultimate'), '<span style="color:#2ECC71">'.__('Upgrade to PRO', 'countdown-timer-ultimate').'</span>', 'manage_options', 'wpemct-premium', array($this, 'wpemct_premium_page') );
	}

	/**
	 * How it work Page HTML
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_designs_page() {
		include_once( WPEMCT_DIR . '/includes/admin/wpemct-how-it-work.php' );
	}

	/**
	 * Premium Feature Page HTML
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_premium_page() {
		include_once( WPEMCT_DIR . '/includes/admin/settings/premium.php' );
	}

	/**
	 * Post Settings Metabox
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_post_sett_metabox() {
		add_meta_box( 'wpemct-post-sett', __( 'WP Countdown Timer Settings - Settings', 'countdown-timer-ultimate' ), array($this, 'wpemct_post_sett_mb_content'), WPEMCT_POST_TYPE, 'normal', 'high' );
	}

	/**
	 * Post Settings Metabox HTML
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_post_sett_mb_content() {
		include_once( WPEMCT_DIR .'/includes/admin/metabox/wpemct-sett-metabox.php');
	}

	/**
	 * Function to save metabox values
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_save_metabox_value( $post_id ) {

		global $post_type;

		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )                	// Check Autosave
		|| ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] )  	// Check Revision
		|| ( $post_type !=  WPEMCT_POST_TYPE ) )              					// Check if current post type is supported.
		{
			return $post_id;
		}

		$prefix = WPEMCT_META_PREFIX; // Taking metabox prefix

		// General Settings
		$date 					= isset($_POST[$prefix.'timer_date'])					? wpemct_clean($_POST[$prefix.'timer_date']) 					: '';
		$animation 				= isset($_POST[$prefix.'timercircle_animation'])		? wpemct_clean($_POST[$prefix.'timercircle_animation']) 			: '';
		$circlewidth			= isset($_POST[$prefix.'timercircle_width'])			? wpemct_clean($_POST[$prefix.'timercircle_width']) 				: '';
		$backgroundwidth		= isset($_POST[$prefix.'timerbackground_width'])		? wpemct_clean_numeric($_POST[$prefix.'timerbackground_width']) 	: '';
		$backgroundcolor		= isset($_POST[$prefix.'timerbackground_color'])		? wpemct_clean_colors($_POST[$prefix.'timerbackground_color']) 	: '';
		$timer_width 			= isset($_POST[$prefix.'timer_width'])					? wpemct_clean_numbers($_POST[$prefix.'timer_width']) 			: '';

		// Days Settings
		$is_days				= !empty($_POST[$prefix.'is_timerdays'])				? 1 : 0;
		$days_text 				= isset($_POST[$prefix.'timer_day_text'])				? wpemct_clean($_POST[$prefix.'timer_day_text']) 					: 'Days';
		$daysbackgroundcolor	= isset($_POST[$prefix.'timerdaysbackground_color'])	? wpemct_clean_colors($_POST[$prefix.'timerdaysbackground_color']) 		: '';

		// Hours Settings
		$is_hours				= !empty($_POST[$prefix.'is_timerhours']) 				? 1 : 0;
		$hours_text 			= isset($_POST[$prefix.'timer_hour_text']) 				? wpemct_clean($_POST[$prefix.'timer_hour_text']) 				: 'Hours';
		$hoursbackgroundcolor	= isset($_POST[$prefix.'timerhoursbackground_color'])	? wpemct_clean_colors($_POST[$prefix.'timerhoursbackground_color']) 		: '';

		// minutes Settings
		$is_minutes				= !empty($_POST[$prefix.'is_timerminutes'])				? 1 : 0;
		$minutes_text 			= isset($_POST[$prefix.'timer_minute_text'])			? wpemct_clean($_POST[$prefix.'timer_minute_text']) 				: 'Minutes';
		$minutesbackgroundcolor	= isset($_POST[$prefix.'timerminutesbackground_color']) ? wpemct_clean_colors($_POST[$prefix.'timerminutesbackground_color']) 	: '';

		// seconds Settings
		$is_seconds				= !empty($_POST[$prefix.'is_timerseconds'])				? 1 : 0;
		$seconds_text 			= isset($_POST[$prefix.'timer_second_text'])			? wpemct_clean($_POST[$prefix.'timer_second_text']) 				: 'Seconds';
		$secondsbackgroundcolor	= isset($_POST[$prefix.'timersecondsbackground_color']) ? wpemct_clean_colors($_POST[$prefix.'timersecondsbackground_color']) 	: '';

		// General Settings
		update_post_meta($post_id, $prefix.'timer_date', $date);
		update_post_meta($post_id, $prefix.'timercircle_animation', $animation);
		update_post_meta($post_id, $prefix.'timercircle_width', $circlewidth);
		update_post_meta($post_id, $prefix.'timerbackground_width', $backgroundwidth);
		update_post_meta($post_id, $prefix.'timerbackground_color', $backgroundcolor);
		update_post_meta($post_id, $prefix.'timer_width', $timer_width);

		// Days Settings
		update_post_meta($post_id, $prefix.'is_timerdays', $is_days);
		update_post_meta($post_id, $prefix.'timer_day_text', $days_text);
		update_post_meta($post_id, $prefix.'timerdaysbackground_color', $daysbackgroundcolor);

		// Hours Settings
		update_post_meta($post_id, $prefix.'is_timerhours', $is_hours);
		update_post_meta($post_id, $prefix.'timer_hour_text', $hours_text);
		update_post_meta($post_id, $prefix.'timerhoursbackground_color', $hoursbackgroundcolor);

		// minutes Settings
		update_post_meta($post_id, $prefix.'is_timerminutes', $is_minutes);
		update_post_meta($post_id, $prefix.'timer_minute_text', $minutes_text);
		update_post_meta($post_id, $prefix.'timerminutesbackground_color', $minutesbackgroundcolor);

		// seconds Settings
		update_post_meta($post_id, $prefix.'is_timerseconds', $is_seconds);
		update_post_meta($post_id, $prefix.'timer_second_text', $seconds_text);
		update_post_meta($post_id, $prefix.'timersecondsbackground_color', $secondsbackgroundcolor);
	}

	/**
	 * Add custom column to Post listing page
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_posts_columns( $columns ) {

		$new_columns['wpemct_shortcode'] = __('Shortcode', 'countdown-timer-ultimate');
		$columns = wpemct_add_array( $columns, $new_columns, 1, true );

		return $columns;
	}

	/**
	 * Add custom column data to Post listing page
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.0.0
	 */
	function wpemct_post_columns_data( $column, $post_id ) {

		global $post;

		// Taking some variables
		$prefix = WPEMCT_META_PREFIX;

		switch ($column) {
			case 'wpemct_shortcode':

				echo '<div class="wpos-copy-clipboard wpemct-shortcode-preview">[wpemct-countdown id="'.$post_id.'"]</div> <br/>';
				break;
		}
	}

	/**
	 * Admin Prior Process
	 * 
	 * @package WP Event Manager - Countdown Timer
	 * @since 1.1.4
	 */
	function wpemct_admin_init_process() {

		// If plugin notice is dismissed
		if( isset($_GET['message']) && $_GET['message'] == 'wpemct-plugin-notice' ) {
			set_transient( 'wpemct_install_notice', true, 604800 );
		}
	}
}

$wpemct_admin = new Wpemct_Admin();