<?php
/**
 * Script Class
 *
 * Handles the script and style 
 *
 * @package Wpemct Analytic
 * @since 1.0
 */

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Wpemct_Anylc_Script {

	function __construct() {

        // Action to add style backend
		add_action( 'admin_enqueue_scripts', array($this, 'wpemct_anylc_admin_script_style') );
	}

     /**
	 * Enqueue script for backend
	 * 
	 * @package Wpemct Analytic
	 * @since 1.0
	 */
    function wpemct_anylc_admin_script_style( $hook ) {

		// Process Promotion Data
		if( !empty($_GET['message']) && $_GET['message'] == 'wpemct_anylc_promotion' && !empty($_GET['wpemct_anylc_pdt']) && !empty($_GET['wpemct_anylc_promo_pdt']) ) {
			global $wpemct_analytics_product;

			$promotion 				= 1;
			$wpemct_anylc_promo_pdt	= sanitize_text_field( $_GET['wpemct_anylc_promo_pdt'] );
			$promotion_pdt 			= explode( ',', $wpemct_anylc_promo_pdt );

			$anylc_pdt 		= sanitize_text_field( $_GET['wpemct_anylc_pdt'] );
			$anylc_pdt_data = isset( $wpemct_analytics_product[ $anylc_pdt ] ) ? $wpemct_analytics_product[ $anylc_pdt ] : false;

			if( !empty($promotion_pdt) ) {
				foreach ($promotion_pdt as $pdt_key => $pdt) {
					if( isset( $anylc_pdt_data['promotion'][$pdt]['file'] ) ) {
						$promotion_pdt_data[] = $anylc_pdt_data['promotion'][$pdt]['file'];
					}
				}
			}
		}

    	// Registring admin Style
		wp_register_style( 'wpemct-anylc-admin-style', WPEMCT_ANYLC_URL.'assets/css/wpemct-anylc-admin.css', null, WPEMCT_ANYLC_VERSION );
		wp_enqueue_style( 'wpemct-anylc-admin-style' );

		// Registring admin script
		wp_register_script( 'wpemct-anylc-admin-script', WPEMCT_ANYLC_URL.'assets/js/wpemct-anylc-admin.js', array('jquery'), WPEMCT_ANYLC_VERSION, true );
		wp_localize_script( 'wpemct-anylc-admin-script', 'WpemctAnylc', array(
																		'promotion' 	=> isset($promotion) ? 1 : 0,
																		'promotion_pdt' => isset( $promotion_pdt_data ) ? $promotion_pdt_data : 0,
																	));
		wp_enqueue_script( 'wpemct-anylc-admin-script' );
    }
}

$wpemct_anylc_script = new Wpemct_Anylc_Script();