<?php

/**
Plugin Name: WP Event Manager - Event Countdown
Plugin URI: https://www.wp-eventmanager.com
Description: Easy to add and display responsive Countdown timer on your website. Also work with Gutenberg shortcode block.
Author: WP Event Manager
Author URI: https://www.wp-eventmanager.com
Text Domain: wpemct-event-countdown-timer
Domain Path: /languages
Version: 1.0.0
Since: 1.0.0
Requires WordPress Version at least: 4.1
Copyright: 2020 WP Event Manager
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
 **/


if (
    !defined('ABSPATH')
) {
    exit; // Exit if accessed directly
}

if (
    !defined('WPEMCT_VERSION')
) {
    define('WPEMCT_VERSION', '1.0'); // Version of plugin
}

if (
    !defined('WPEMCT_DIR')
) {
    define('WPEMCT_DIR', dirname(__FILE__)); // Plugin dir
}

if (
    !defined('WPEMCT_URL')
) {
    define('WPEMCT_URL', plugin_dir_url(__FILE__)); // Plugin url
}

if (
    !defined('WPEMCT_PLUGIN_BASENAME')
) {
    define('WPEMCT_PLUGIN_BASENAME', plugin_basename(__FILE__)); // plugin base name
}

if (
    !defined('WPEMCT_POST_TYPE')
) {
    define('WPEMCT_POST_TYPE', 'wpemct_countdown'); // Plugin post type
}

if (
    !defined('WPEMCT_META_PREFIX')
) {
    define('WPEMCT_META_PREFIX', '_wpemct_'); // Plugin metabox prefix
}
if (!defined('WPEMCT_PRO_LINK')) {
    define('WPEMCT_PRO_LINK', 'https://www.wp-eventmanager.com'); // Plugin link
}


/**
 * Load Text Domain
 * This gets the plugin ready for translation
 * 
 * @package WP Event Manager - Event Countdown
 * @since 1.0.0
 */
function wpemct_load_textdomain() {

	global $wp_version;

	// Set filter for plugin's languages directory
	$wpemct_lang_dir = dirname(WPEMCT_PLUGIN_BASENAME ) . '/languages/';
	$wpemct_lang_dir = apply_filters( 'wpemct_languages_directory', $wpemct_lang_dir );

	// Traditional WordPress plugin locale filter.
	$get_locale = get_locale();

	if ( $wp_version >= 4.7 ) {
		$get_locale = get_user_locale();
	}


    // Traditional WordPress plugin locale filter
    $locale = apply_filters('plugin_locale',  $get_locale, 'wp-event-manager-countdown-timer');
    $mofile = sprintf('%1$s-%2$s.mo', 'wp-event-manager-countdown-timer', $locale);

    // Setup paths to current locale file
    $mofile_global  = WP_LANG_DIR . '/plugins/' . basename(WPEMCT_DIR) . '/' . $mofile;

    if (file_exists($mofile_global)) { // Look in global /wp-content/languages/plugin-name folder
        load_textdomain('wp-event-manager-countdown-timer', $mofile_global);
    } else { // Load the default language files
        load_plugin_textdomain('wp-event-manager-countdown-timer', false, $wpemct_lang_dir);
    }
}

add_action('plugins_loaded', 'wpemct_load_textdomain');


/**
 * Activation Hook
 * 
 * Register plugin activation hook.
 * 
 * @package WP Event Manager - Event Countdown
 * @since 1.0.0
 */
register_activation_hook(__FILE__, 'wpemct_install');

/**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package /**
 * Deactivation Hook
 * 
 * Register plugin deactivation hook.
 * 
 * @package WP Event Manager - Event Countdown
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'wpemct_uninstall');

 /* @since 1.0.0
 */
register_deactivation_hook(__FILE__, 'wpemct_uninstall');


/**
 * Plugin Setup (On Activation)
 * 
 * Does the initial setup,
 * stest default values for the plugin options.
 * 
 * @package WP Event Manager - Event Countdown
 * @since 1.0.0
 */
function wpemct_install()
{

    wpemct_register_post_type();

    // IMP need to flush rules for custom registered post type
    flush_rewrite_rules();

   
}





/**
 * Plugin Setup (On Deactivation)
 * 
 * Delete plugin options.
 * 
 * @package WP Event Manager - Event Countdown
 * @since 1.0.0
 */
function wpemct_uninstall()
{

    // IMP need to flush rules for custom registered post type
    flush_rewrite_rules();
}

/**
 * Function to display admin notice of activated plugin.
 * 
 * @package WP Event Manager - Event Countdown
 * @since 1.0.0
 */
function wpemct_countdown_admin_notice() {
	
	global $pagenow;

	$dir 				= WP_PLUGIN_DIR . '/wpemct-event-countdown/wpemct-event-countdown.php';
	$notice_link 		= add_query_arg( array('message' => 'wpemct-plugin-notice'), admin_url('plugins.php') );
	$notice_transient 	= get_transient( 'wpemct_install_notice' );

    	}


// Action to display notice
add_action('admin_notices', 'wpemct_countdown_admin_notice');

// Functions file
require_once(WPEMCT_DIR . '/includes/wpemct-functions.php');

// Plugin Post Type File
require_once(WPEMCT_DIR . '/includes/wpemct-post-types.php');

// Admin Class File
require_once(WPEMCT_DIR . '/includes/admin/class-wpemct-admin.php');

// Script Class File
require_once(WPEMCT_DIR . '/includes/class-wpemct-script.php');

// Shortcode File
require_once(WPEMCT_DIR . '/includes/shortcode/wpemct-shortcode.php');


/* Recommended Plugins Starts */
if (is_admin()) {
    require_once(WPEMCT_DIR . '/wpemct-plugins/wpemct-recommendation.php');

    wpemct_espbw_init_module(array(
        'prefix'    => 'wpemct',
        'menu'        => 'edit.php?post_type=' . WPEMCT_POST_TYPE,
        'position'    => 2,
    ));
}
/* Recommended Plugins Ends */

/* Plugin Wpem Analytics Data Starts */
function wpemct_analytics_anl31_load()
{

    require_once dirname(__FILE__) . '/wpemct-analytics/wpemct-analytics.php';

    $wpemct_analytics =  wpemct_anylc_init_module(array(
        'id'             => 31,
        'file'             => plugin_basename(__FILE__),
        'name'             => 'WP Event Manager - Event Countdown',
        'slug'             => 'wp-event-manager-event-countdown',
        'type'             => 'plugin',
        'menu'             => 'edit.php?post_type=wpemct_countdown',
        'text_domain'    => 'wp-event-manager-event-countdown',
    ));

    return $wpemct_analytics;
}

// Init Analytics
wpemct_analytics_anl31_load();
/* Plugin Wpem Analytics Data Ends */